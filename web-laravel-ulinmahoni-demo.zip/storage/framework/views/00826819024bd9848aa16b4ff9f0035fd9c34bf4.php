<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="px-4 sm:px-6 lg:px-8 py-8 w-full max-w-9xl mx-auto">
        <!-- Page header -->
        <div class="sm:flex sm:justify-between sm:items-center mb-8">
            <!-- Left: Title -->
            <div class="mb-4 sm:mb-0">
                <h1 class="text-2xl md:text-3xl text-slate-800 font-bold">
                    Inventory COGS 📋
                </h1>
            </div>
        </div>

        <!-- Table -->
        <div class="table-responsive">
            <table id="cogs" class="table table-striped table-bordered text-xs" style="width:100%">
                <thead>
                    <tr>
                        <th class="text-center">Inventory Code</th>
                        <th class="text-center">Inventory Name</th>
                        <th class="text-center">Previous COGS (IDR)</th>
                        <th class="text-center">Current COGS (IDR)</th>
                        <th class="text-center">PO Currency</th>
                        <th class="text-center">PO Min Price</th>
                        <th class="text-center">PO Max Price</th>
                        <th class="text-center">Currency Last PO</th>
                        <th class="text-center">Price Last PO</th>
                        <th class="text-center">Date Last PO</th>
                    </tr>
                </thead>
            </table>
        </div>
    </div>

    <?php $__env->startSection('js-page'); ?>
    <script>
        $(document).ready(function () {
            $('#cogs').DataTable({
                responsive: true,
                processing: true,
                serverSide: false,
                stateServe: true,
                language: {
                    search: "Search Inventory Name: "
                },
                ajax: {
                    url: "<?php echo e(route('cogs.getdata')); ?>"
                },
                columns: [
                    {
                        data: "idinventory",
                        name: "idinventory"
                    },
                    {
                        data: "inventory_name",
                        name: "inventory_name"
                    },
                    {
                        data: "cogs_previous",
                        name: "cogs_previous"
                    },
                    {
                        data: "cogs_now",
                        name: "cogs_now"
                    },
                    {
                        data: "currency",
                        name: "currency"
                    },
                    {
                        data: "min_po",
                        name: "min_po"
                    },
                    {
                        data: "max_po",
                        name: "max_po"
                    },
                    {
                        data: "currency_last_purchase",
                        name: "currency_last_purchase"
                    },
                    {
                        data: "last_purchase_price",
                        name: "last_purchase_price"
                    },
                    {
                        data: "last_purchase_date",
                        name: "last_purchase_date"
                    },
                ],
                columnDefs: [
                    { className: 'text-center', targets: [ 4, 7, 9] },
                    { className: 'text-right', targets: [ 2, 3, 5, 6, 8 ] },
                ], lengthMenu: [[30, 50, 100, -1], [30, 50, 100, 'All']]
            });
        });
    </script>
    <?php $__env->stopSection(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?><?php /**PATH C:\Users\TSNO - Web Developer\Documents\web-laravel-iss\resources\views/pages/inventory/cogs/index.blade.php ENDPATH**/ ?>