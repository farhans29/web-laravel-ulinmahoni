<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="px-4 sm:px-6 lg:px-8 py-8 w-full max-w-9xl mx-auto">
        <!-- Page header -->
        <div class="sm:flex sm:justify-between sm:items-center mb-8">
            <!-- Left: Title -->
            <div class="mb-4 sm:mb-0">
                <h1 class="text-2xl md:text-3xl text-slate-800 font-bold">
                    Leave Approval 📚
                </h1>
            </div>
        </div>

        <!-- Table -->
        <div class="table-responsive">
            <table id="approve" class="table table-striped table-bordered text-xs" style="width:100%">
                <thead>
                    <tr>
                        <th class="text-center">Form Date</th>
                        <th class="text-center">Leave Request #</th>
                        <th class="text-center">Employee</th>
                        <th class="text-center">Start Leave</th>
                        <th class="text-center">End Leave</th>
                        <th class="text-center">Leave Days</th>
                        <th class="text-center">Type</th>
                        <th class="text-center">Notes</th>
                        <th class="text-center">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>2022-12-01</td>
                        <td>001</td>
                        <td>Ahmad Fajar</td>
                        <td>2022-12-05</td>
                        <th>2022-12-07</th>
                        <th>2</th>
                        <th>Sick Leave</th>
                        <th>I got sick and need take a rest at home</th>
                        <td>
                            <button class='text-blue-400'>View</button>
                            <button class='text-green-400 ml-4'>Approve</button>
                            <button class='text-red-400 ml-4'>Denied</button>
                        </td>
                    </tr>
                    <tr>
                        <td>2022-12-10</td>
                        <td>005</td>
                        <td>Fatah</td>
                        <td>2022-12-10</td>
                        <th>2022-12-15</th>
                        <th>5</th>
                        <th>Unpaid Leave</th>
                        <th>I want to holiday</th>
                        <td>
                            <button class='text-blue-400'>View</button>
                            <button class='text-green-400 ml-4'>Approve</button>
                            <button class='text-red-400 ml-4'>Denied</button>
                        </td>
                    </tr>
                    <tr>
                        <td>2022-12-07</td>
                        <td>003</td>
                        <td>Sheren Natasya</td>
                        <td>2022-12-09</td>
                        <th>2023-03-10</th>
                        <th>90</th>
                        <th>Maternity Leave</th>
                        <th>Preganancy</th>
                        <td>
                            <button class='text-blue-400'>View</button>
                            <button class='text-green-400 ml-4'>Approve</button>
                            <button class='text-red-400 ml-4'>Denied</button>
                        </td>
                    </tr>
                    <tr>
                        <td>2022-12-10</td>
                        <td>006</td>
                        <td>Kimi</td>
                        <td>2022-12-11</td>
                        <th>2022-12-13</th>
                        <th>2</th>
                        <th>Sick Leave</th>
                        <th>I got sick and need take a rest at home</th>
                        <td>
                            <button class='text-blue-400'>View</button>
                            <button class='text-green-400 ml-4'>Approve</button>
                            <button class='text-red-400 ml-4'>Denied</button>
                        </td>
                    </tr>
                    <tr>
                        <td>2022-12-02</td>
                        <td>002</td>
                        <td>Ahmad Fajar</td>
                        <td>2022-12-20</td>
                        <th>2022-12-25</th>
                        <th>5</th>
                        <th>Unpaid Leave</th>
                        <th>-</th>
                        <td>
                            <button class='text-blue-400'>View</button>
                            <button class='text-green-400 ml-4'>Approve</button>
                            <button class='text-red-400 ml-4'>Denied</button>
                        </td>
                    </tr>
                    <tr>
                        <td>2022-12-07</td>
                        <td>004</td>
                        <td>Trisno</td>
                        <td>2022-12-08</td>
                        <th>2022-12-10</th>
                        <th>2</th>
                        <th>Sick Leave</th>
                        <th>I need bed rest</th>
                        <td>
                            <button class='text-blue-400'>View</button>
                            <button class='text-green-400 ml-4'>Approve</button>
                            <button class='text-red-400 ml-4'>Denied</button>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>

    <?php $__env->startSection('js-page'); ?>
    <script>
        $(document).ready(function () {
            $('#approve').DataTable({
                responsive: true,
                processing: true,
                serverSide: false,
                stateServe: true,
                language: {
                    search: "Search Employee: "
                },
                columnDefs: [
                    { className: 'text-center', targets: [1, 5] },
                    { className: 'text-right', targets: [] },
                ], lengthMenu: [[30, 50, 100, -1], [30, 50, 100, 'All']]
            });
        });
    </script>
    <?php $__env->stopSection(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?><?php /**PATH C:\Users\TSNO - Web Developer\Documents\crm app-web_laravel\resources\views/pages/hr/leaveapproval/index.blade.php ENDPATH**/ ?>