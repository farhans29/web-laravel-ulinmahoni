

<div class="col-span-full xl:col-span-6 bg-white shadow-lg rounded-sm border border-slate-200">
    <header class="px-5 py-4 border-b border-slate-100">
        <h2 class="font-semibold text-slate-800">Recent Activity</h2>
    </header>
    <div class="p-3">

        <!-- Card content -->
        <!-- "Today" group -->
        <div>
            <header class="text-xs uppercase text-slate-400 bg-slate-50 rounded-sm font-semibold p-2">Today</header>
            <ul class="my-1">
                <!-- Item -->
                <?php $__currentLoopData = $dataCalendars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $activity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>    
                <li class="flex px-2">
                    <div class="grow flex items-center border-b border-slate-100 text-sm py-2">
                        <div class="grow flex justify-between">
                            <div class="self-center"><a class="font-medium text-slate-800 hover:text-slate-900" href="#0"><?php echo e($activity->add_by); ?></a> mentioned <a class="font-medium text-slate-800" href="#0"><?php echo e($activity->invitations); ?></a> in a new post</div>
                            <div class="shrink-0 self-end ml-2">
                                <a href="<?php echo e(route('calendar')); ?>" class="font-medium text-indigo-500 hover:text-indigo-600" href="#0">View<span class="hidden sm:inline"> -&gt;</span></a>
                            </div>
                        </div>
                    </div>
                </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
        <!-- "Yesterday" group -->
        <div>
            <header class="text-xs uppercase text-slate-400 bg-slate-50 rounded-sm font-semibold p-2">Tomorrow</header>
            <ul class="my-1">
                <!-- Item -->
                <li class="flex px-2">
                    <div class="grow flex items-center border-b border-slate-100 text-sm py-2">
                        <div class="grow flex justify-between">
                            <div class="self-center"><a class="font-medium text-slate-800 hover:text-slate-900" href="#0">240+</a> users have subscribed to <a class="font-medium text-slate-800" href="#0">Newsletter #1</a></div>
                            <div class="shrink-0 self-end ml-2">
                                <a class="font-medium text-indigo-500 hover:text-indigo-600" href="#0">View<span class="hidden sm:inline"> -&gt;</span></a>
                            </div>
                        </div>
                    </div>
                </li>
                <!-- Item -->
                <li class="flex px-2">
                    <div class="grow flex items-center text-sm py-2">
                        <div class="grow flex justify-between">
                            <div class="self-center">The post <a class="font-medium text-slate-800" href="#0">Post Name</a> was suspended by <a class="font-medium text-slate-800 hover:text-slate-900" href="#0">Nick Mark</a></div>
                            <div class="shrink-0 self-end ml-2">
                                <a class="font-medium text-indigo-500 hover:text-indigo-600" href="#0">View<span class="hidden sm:inline"> -&gt;</span></a>
                            </div>
                        </div>
                    </div>
                </li>
            </ul>
        </div>

    </div>
</div><?php /**PATH C:\Users\TSNO - Web Developer\Documents\crm app-web_laravel\resources\views/components/dashboard/dashboard-card-10.blade.php ENDPATH**/ ?>