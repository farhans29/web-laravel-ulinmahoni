<button <?php echo e($attributes->merge(['type' => 'submit', 'class' => 'btn bg-indigo-500 hover:bg-indigo-600 text-white whitespace-nowrap'])); ?>>
    <?php echo e($slot); ?>

</button>
<?php /**PATH C:\Users\TSNO - Web Developer\Documents\crm app-web_laravel\resources\views/vendor/jetstream/components/button.blade.php ENDPATH**/ ?>