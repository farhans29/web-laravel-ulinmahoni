<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="px-4 sm:px-6 lg:px-8 py-8 w-full max-w-9xl mx-auto">
        <!-- Page header -->
        <div class="sm:flex sm:justify-between sm:items-center mb-8">
            <!-- Left: Title -->
            <div class="mb-4 sm:mb-0">
                <h1 class="text-2xl md:text-3xl text-slate-800 font-bold">
                    Days Inventory Outstanding - DOI 📋
                </h1>
            </div>
        </div>

        <!-- Table -->
        <div class="table-responsive text-xs">
            <table id="doi" class="table table-striped table-bordered" style="width:100%">
                <thead>
                    <tr>
                        <th class="text-lg">Month</th>
                        <th class="text-sm">COGS (Monthly) IDR</th>
                        <th>COGS (YtD) IDR</th>
                        <th class="text-sm text-center">Inventory (Monthly Average) IDR</th>
                        <th class="text-xs">Turnover (Monthly)</th>
                        <th class="text-xs">DOI (Monthly)</th>
                        <th class="text-xs">Turnover (YtD)</th>
                        <th class="text-xs">DOI (Days Ratio)</th>
                        <th class="text-xs">DOI (Monthly YtD)</th>
                    </tr>
                </thead>
            </table>
        </div>
    </div>

    <?php $__env->startSection('js-page'); ?>
    <script>
        $(document).ready(function () {
            $('#doi').DataTable({
                responsive: true,
                processing: true,
                serverSide: false,
                stateServe: true,
                bFilter: false,
                lengthChange: false,
                paging: false,
                sort: false,
                ajax: {
                    url: "<?php echo e(route('doi.getdata')); ?>"
                },
                columns: [
                    {
                        data: "month",
                        name: "month",
                        orderable: false
                    },
                    {
                        data: "cogsm",
                        name: "cogsm"
                    },
                    {
                        data: "cogsy",
                        name: "cogsy"
                    },
                    {
                        data: "invma",
                        name: "invma"
                    },
                    {
                        data: "turnoverm",
                        name: "turnoverm"
                    },
                    {
                        data: "doim",
                        name: "doim"
                    },
                    {
                        data: "turnovery",
                        name: "turnovery"
                    },
                    {
                        data: "doidr",
                        name: "doidr"
                    },
                    {
                        data: "doimy",
                        name: "doimy"
                    },
                ],
                columnDefs: [
                    { className: 'text-center', targets: [4, 5, 6, 7, 8] },
                    { className: 'text-right', targets: [1, 2, 3] },
                ], lengthMenu: [[30, 50, 100, -1], [30, 50, 100, 'All']]
            });
        });
    </script>
    <?php $__env->stopSection(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?><?php /**PATH C:\Users\TSNO - Web Developer\Documents\crm app-web_laravel\resources\views/pages/inventory/doi/index.blade.php ENDPATH**/ ?>