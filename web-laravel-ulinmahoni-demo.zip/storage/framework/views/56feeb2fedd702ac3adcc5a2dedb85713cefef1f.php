<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="px-4 sm:px-6 lg:px-8 py-8 w-full max-w-9xl mx-auto">
        <!-- Page header -->
        <div class="sm:flex sm:justify-between sm:items-center mb-8">
            <!-- Left: Title -->
            <div class="mb-4 sm:mb-0">
                <h1 class="text-2xl md:text-3xl text-slate-800 font-bold">
                    Leave Request 📚
                </h1>
            </div>
        </div>

        <a class="mb-3 btn bg-indigo-500 hover:bg-indigo-600 text-white text-xs <?php if(Route::is('leaverequest.form')): ?><?php echo e('!text-indigo-500'); ?><?php endif; ?> mb-3"
                    href="<?php echo e(route('leaverequest.form')); ?>">
                    <svg class="w-4 h-4 fill-current opacity-50 shrink-0" viewBox="0 0 16 16">
                        <path
                            d="M15 7H9V1c0-.6-.4-1-1-1S7 .4 7 1v6H1c-.6 0-1 .4-1 1s.4 1 1 1h6v6c0 .6.4 1 1 1s1-.4 1-1V9h6c.6 0 1-.4 1-1s-.4-1-1-1z" />
                    </svg>
                    <span class="ml-2 text-xs">Create Leave Request</span>
        </a>

        <!-- Table -->
        <div class="table-responsive">
            <table id="request" class="table table-striped table-bordered text-xs" style="width:100%">
                <thead>
                    <tr>
                        <th class="text-center">Form Date</th>
                        <th class="text-center">Leave Request #</th>
                        <th class="text-center">Employee</th>
                        <th class="text-center">Start Leave</th>
                        <th class="text-center">End Leave</th>
                        <th class="text-center">Leave Days</th>
                        <th class="text-center">Type</th>
                        <th class="text-center">Notes</th>
                        <th class="text-center">Status</th>
                        <th class="text-center">Action</th>
                    </tr>
                </thead>
            </table>
        </div>
    </div>

    <?php $__env->startSection('js-page'); ?>
    <script>
        $(document).ready(function () {
            $('#request').DataTable({
                responsive: true,
                processing: true,
                serverSide: false,
                stateServe: true,
                language: {
                    search: "Search : "
                },
                ajax: {
                    url: "<?php echo e(route('leaverequest.getdata')); ?>"
                },
                columns: [
                    {
                        data: "created_at",
                        name: "created_at"
                    },
                    {
                        data: "id",
                        name: "id"
                    },
                    {
                        data: "employee",
                        name: "employee"
                    },
                    {
                        data: "periode_from",
                        name: "periode_from"
                    },
                    {
                        data: "periode_to",
                        name: "periode_to"
                    },
                    {
                        data: "leave_days",
                        name: "leave_days"
                    },
                    {
                        data: "category",
                        name: "category"
                    },
                    {
                        data: "description",
                        name: "description"
                    },
                    {
                        data: "status",
                        name: "status"
                    },
                    {
                        data: "action",
                        name: "action"
                    },
                ],
                columnDefs: [
                    { className: 'text-center', targets: [1, 5] },
                    { className: 'text-right', targets: [] },
                ], lengthMenu: [[30, 50, 100, -1], [30, 50, 100, 'All']]
            });
        });
    </script>
    <?php $__env->stopSection(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?><?php /**PATH C:\Users\TSNO - Web Developer\Documents\web-laravel-iss\resources\views/pages/hr/leaverequest/index.blade.php ENDPATH**/ ?>