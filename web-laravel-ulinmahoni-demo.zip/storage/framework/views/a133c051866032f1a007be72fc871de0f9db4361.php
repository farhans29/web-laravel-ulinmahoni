<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="px-4 sm:px-6 lg:px-8 py-8 w-full max-w-9xl mx-auto">
        <!-- Page header -->
        <div class="sm:flex sm:justify-between sm:items-center mb-8">
            <!-- Left: Title -->
            <div class="mb-4 sm:mb-0">
                <h1 class="text-2xl md:text-3xl text-slate-800 font-bold">
                    Inventory List 📋
                </h1>
            </div>
        </div>

        <!-- status -->
        <div class="flex flex-row">
            <div class="rounded-full bg-green-500 md:break-after-column h-5 w-5 ml-5"></div>
            <p class="flex flex-row ml-1">Active</p>
            <div class="rounded-full bg-black columns-1 h-5 w-5 ml-5"></div>
            <p class="flex flex-row ml-1 mb-3">Not Active</p>
        </div>

        <div class="flex flex-row">
            <p class="flex flex-row text-slate-800 mb-3 text-sm mt-2" for="status">Inventory Status :</p>
                <select id="status" class="status flex flex-row ml-2 mb-3 text-xs" name="status">
                    <option value="">All</option>
                    <option value="0">Not Active</option>
                    <option value="1">Active</option>
                </select>
                <label class="show-zero-filter ms-3 text-slate-800 text-sm mt-2" for="">Don't Show 0 (zero) Stock 
                    <input type="checkbox" id="show-zero" class="stock-show-filter" data-stock="zero" name="show-zero" value="0"/>
                </label>
        </div>
        <!-- Table -->
        <div class="table-responsive">
            <table id="invlist" class="table table-striped table-bordered text-xs" style="width:100%">
                <thead>
                    <tr>
                        <th class="text-center">Label</th>
                        <th class="text-center">Inventory Code</th>
                        <th class="text-center">Inventory Name</th>
                        <th class="text-center">Unit</th>
                        <th class="text-center">On Hand Stock</th>
                        <th class="text-center">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <tr data-stock="zero" class="zero">

                    </tr>
                </tbody>
            </table>
        </div>
    </div>

    <?php $__env->startSection('js-page'); ?>
    <script>
        $(document).ready(function () {
            $('#invlist').DataTable({
                responsive: true,
                processing: true,
                serverSide: false,
                stateServe: true,
                "order": [[ 2, "asc" ]],
                language: {
                    search: "Search Inventory Name: "
                },
                ajax: {
                    url: "<?php echo e(route('invlistzero.getdata')); ?>",
                    data:function(d){
                        d.status = $("#status").val()
                    }
                },
                columns: [
                    {
                        data: "label",
                        name: "label"
                    },
                    {
                        data: "code",
                        name: "code"
                    },
                    {
                        data: "name",
                        name: "name"
                    },
                    {
                        data: "unit",
                        name: "unit"
                    },
                    {
                        data: "global_stock",
                        name: "global_stock"
                    },
                    {
                        data: "action",
                        name: "action"
                    }
                ],
                columnDefs: [
                    { className: 'text-center', targets: [1, 3, 4 ] },
                    { className: 'align-middle', targets: [0, 5 ] },
                ], lengthMenu: [[30, 50, 100, -1], [30, 50, 100, 'All']]
            });

            $(".status").on('change', function (e) {
                e.preventDefault();
                $('#invlist').DataTable().ajax.reload();
            })

            $('#invlist').on("click", ".btn-modal", function () {
                const id = $(this).data('id');
                const code = $(this).data("code");
                const name= $(this).data("name");
                const file1= $(this).data("file1");
                const file2= $(this).data("file2");
                const file3= $(this).data("file3");

                $.ajax({
                    type: "GET",
                    url: `/inventory/invlist/getdata/${code}`,
                    success: function (response) {

                        $(".modal-content").html(`
                            <div class="px-5">
                                <div class="text-sm">
                                    <div class="font-medium text-slate-800 mb-3"></div>
                                </div>

                                <div class="grid md:grid-cols-3 gap-3 mt-3">
                                        <div></div>
                                        <div class="${file1 != 1 ? 'hidden' : ''}">
                                            <label class="text-sm font-medium mb-1">Image Not Uploaded Yet</label>
                                        </div>
                                        <div></div>
                                </div>

                                <div class="grid md:grid-cols-3 gap-3 mt-3">
                                        <div class="${file1 == 1 ? 'hidden' : ''}">
                                            <label class="text-sm font-medium mb-1">Image 1 :</label>
                                            <a href="/inventory/invlist/file1/${code}" target="_blank" class="text-sm font-medium ml-5">View Image</a>
                                        </div>
                                        <div class="${file2 == 1 ? 'hidden' : ''}">
                                            <label class="text-sm font-medium mb-1">Image 2 :</label>
                                            <a href="/inventory/invlist/file2/${code}" target="_blank" class="text-sm font-medium ml-5">View Image</a>
                                        </div>
                                        <div class="${file3 == 1 ? 'hidden' : ''}">
                                            <label class="text-sm font-medium mb-1">Image 3 :</label>
                                            <a href="/inventory/invlist/file3/${code}" target="_blank" class="text-sm font-medium ml-5">View Image</a>
                                        </div>
                                </div>
                            </div>
                        `); 
                    },
                });
            });
        });
    </script>
    <?php $__env->stopSection(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?><?php /**PATH C:\Users\TSNO - Web Developer\Documents\web-laravel-mmp\resources\views/pages/inventory/invlist/indexzero.blade.php ENDPATH**/ ?>