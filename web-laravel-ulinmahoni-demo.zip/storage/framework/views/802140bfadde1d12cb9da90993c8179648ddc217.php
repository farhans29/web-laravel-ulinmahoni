<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['background' => 'bg-white']); ?>
    <div class="px-4 sm:px-6 lg:px-8 py-8 w-full max-w-9xl mx-auto">

        <!-- Page header -->
        <div class="mb-8">
            <h1 class="text-2xl md:text-3xl text-slate-800 font-bold">Create New Project 📝</h1>
        </div>

        <div class="border-t border-slate-200">

            <!-- Components -->
            <div class="space-y-8">

                <!-- Input Types -->
                <div class="px-5 py-4">
                    <div class="space-y-3">
                        <div class="flex flex-col md:flex-row">
                            <label class="block w-full md:w-1/4 text-sm font-medium mb-1" for="company">Company :
                            </label>
                            <input id="company" class="company form-input px-2 py-1 read-only:bg-slate-200" type="text"
                                readonly disabled />
                            <button
                                class="ml-2 btn bg-indigo-500 hover:bg-indigo-600 text-white <?php if(Route::is('proyek.create')): ?><?php echo e('!text-indigo-500'); ?><?php endif; ?>"
                                href="<?php echo e(route('proyek.create')); ?>">
                                <svg class="w-4 h-4" viewBox="0 0 16 16" xmlns="http://www.w3.org/2000/svg">
                                    <path class="fill-current text-slate-200"
                                        d="M7 14c-3.86 0-7-3.14-7-7s3.14-7 7-7 7 3.14 7 7-3.14 7-7 7zM7 2C4.243 2 2 4.243 2 7s2.243 5 5 5 5-2.243 5-5-2.243-5-5-5z" />
                                    <path class="fill-current text-slate-200"
                                        d="M15.707 14.293L13.314 11.9a8.019 8.019 0 01-1.414 1.414l2.393 2.393a.997.997 0 001.414 0 .999.999 0 000-1.414z" />
                                </svg>
                                <span></span>
                            </button>
                        </div>
                        <div class="flex flex-col md:flex-row">
                            <label class="block w-full md:w-1/4 text-sm font-medium mb-1" for="company">Company PIC:
                            </label>
                            <select class="w-full md:w-1/4">
                                <option></option>
                            </select>
                            <a class="ml-3 btn bg-indigo-500 hover:bg-indigo-600 text-white <?php if(Route::is('proyek.create')): ?><?php echo e('!text-indigo-500'); ?><?php endif; ?>"
                                href="<?php echo e(route('proyek.create')); ?>">
                                <svg class="w-4 h-4 fill-current  text-slate-200" viewBox="0 0 16 16">
                                    <path
                                        d="M15 7H9V1c0-.6-.4-1-1-1S7 .4 7 1v6H1c-.6 0-1 .4-1 1s.4 1 1 1h6v6c0 .6.4 1 1 1s1-.4 1-1V9h6c.6 0 1-.4 1-1s-.4-1-1-1z" />
                                </svg>
                                <span></span>
                            </a>
                        </div>
                        <div class="flex justify-between flex-col md:flex-row">
                            <label class="block w-full md:w-1/4 text-sm font-medium mb-1" for="pic">Sales Name :
                            </label>
                            <select id="pic" name="pic" class="pic form-select w-full md:w-3/4 px-2 py-1">
                                <option>Trisno</option>
                                <option>Admin</option>
                                <option>Admin Sales Kedua</option>
                                <option>Admin Warehouse</option>
                                <option>Anggi Prisilya</option>
                                <option>Bemmy</option>
                                <option>Billy</option>
                                <option>Bismo</option>
                                <option>Dana</option>
                                <option>Debby</option>
                                <option>Dwian Naurah</option>
                                <option>Edy Yun</option>
                                <option>Elisabet</option>
                                <option>External Finance</option>
                                <option>Finance Supervisor</option>
                                <option>Gyovanni Prayoga</option>
                                <option>Ibnu Nur Setyaji</option>
                                <option>Ikhsan</option>
                                <option>Mediana</option>
                                <option>Novenia</option>
                                <option>Purchasing</option>
                                <option>Rey Kardiono</option>
                                <option>Rinayanti</option>
                                <option>Staff Finance Accounting</option>
                                <option>Stefanie</option>
                                <option>Theovint</option>
                                <option>Trisna</option>
                                <option>Veinny</option>
                                <option>Yemima</option>
                            </select>
                        </div>
                        <div class="flex justify-between flex-col md:flex-row">
                            <label class="block w-full md:w-1/4 text-sm font-medium mb-1" for="company">Project Name :
                            </label>
                            <input id="company"
                                class="company form-input w-full md:w-3/4 px-2 py-1 read-only:bg-slate-200" type="text"/>
                        </div>
                        <div class="flex justify-between flex-col md:flex-row">
                            <label class="block w-full md:w-1/4 text-sm font-medium mb-1" for="pic">Status :
                            </label>
                            <select id="pic" name="pic" class="pic form-select w-full md:w-3/4 px-2 py-1">
                                <option>Open</option>
                                <option>Pending</option>
                                <option>Close</option>
                            </select>
                        </div>
                        <div class="flex justify-between flex-col md:flex-row">
                            <label class="block w-full md:w-1/4 text-sm font-medium mb-1" for="company">Project
                                Description :
                            </label>
                            <textarea id="desc" name="desc"
                                class="description form-input w-full md:w-3/4 px-2 py-1 read-only:bg-slate-200" rows="3"> </textarea>
                        </div>
                        <div class="flex justify-between flex-col md:flex-row">
                            <label class="block w-full md:w-1/4 text-sm font-medium mb-1" for="file">File Upload
                                (PDF) :
                            </label>
                            <input id="file" name="file" class="form-input w-full md:w-3/4 px-2 py-1" type="file"
                                accept="application/pdf" />
                        </div>

                        <center><button class="btn bg-indigo-500 hover:bg-indigo-600 text-white mt-5">
                                <span class="hidden xs:block ml-5 mr-5">Create New Project</span>
                            </button> </center>
                    </div>
                </div>
            </div>

        </div>

    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?><?php /**PATH C:\Users\TSNO - Web Developer\Documents\crm app-web_laravel\resources\views/pages/tasks/proyek/create.blade.php ENDPATH**/ ?>