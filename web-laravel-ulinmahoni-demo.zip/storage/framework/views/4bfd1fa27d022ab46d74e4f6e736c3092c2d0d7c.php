<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['background' => 'bg-white']); ?>
    <div class="px-4 sm:px-6 lg:px-8 py-8 w-full max-w-9xl mx-auto">

        <!-- Page header -->
        <div class="mb-8">
            <h1 class="text-2xl md:text-3xl text-slate-800 font-bold">Form Leave Request 📝</h1>
        </div>

        <div class="border-t border-slate-200">

            <!-- Components -->
            <div class="space-y-8">

                <!-- Input Types -->
                <div>

                    <!-- Start -->
                    <div>
                        <label class="block text-2xl text-slate-800 font-medium mb-1" for="created_at">Leave Date</label>
                        <input id="created_at" class="form-input w-full" type="text"
                            Value="<?php echo date('Y-m-d'); ?>" />
                    </div>
                    <!-- End -->
                    <div>
                        <!-- Start -->
                        <div>
                            <div class="flex items-center justify-between">
                                <label class="block text-2xl text-slate-800 font-medium mb-1 mt-3"
                                    for="tooltip">Employee Name</label>
                            </div>
                            <input id="name"
                                class="form-input w-full  disabled:border-slate-800 disabled:bg-slate-100 disabled:text-slate-400 mt-2"
                                type="text" value="<?php echo e(Auth::user()->username); ?>" disabled />
                        </div>
                        <!-- End -->
                    </div>

                    <div>
                        <!-- Start -->
                        <div>
                            <label class="block text-2xl text-slate-800 mt-3 font-medium mb-1" for="mandatory">From
                                Date</label>
                            <input type="date" className='text'></input>
                            <span class="mx-4 text-black-500">to</span>
                            <input type="date" className='text'></input>
                        </div>
                        <!-- End -->
                    </div>

                    <div>
                        <label class="block text-2xl text-slate-800 mt-3 font-medium mb-1" for="country">Leave
                            Type</label>
                        <select id="leavetype" class="form-select">
                            <option selected disabled hidden>Select Here</option>
                            <option>Sick Leave</option>
                            <option>Maternity Leave</option>
                            <option>Paternity Leave</option>
                            <option>Bereavement Leave</option>
                            <option>Religious Leave</option>
                            <option>Compensatory Leave</option>
                            <option>Unpaid Leave</option>
                        </select>
                    </div>

                    <div>
                        <div>
                            <label class="block text-2xl text-slate-800 mb-1 mt-3">
                                Notes
                            </label>
                        </div>
                        <textarea id="large" class="form-input w-full py-10 border-slate-800" type="text"
                            placeholder='Type Here'></textarea>
                    </div>

                    <label class="block text-slate-800 text-2xl font-medium mb-1 mt-3 border-slate-800" htmlFor="large">
                        Upload Document
                    </label>
                    <input
                        class="block w-full text-sm text-gray-900 border border-gray-300 rounded-lg cursor-pointer bg-gray-50 dark:text-gray-400 focus:outline-none dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400"
                        aria-describedby="file_input_help" id="file_input" type="file">
                    </input>
                    <p class="mt-1 text-sm text-gray-500 dark:text-gray-300" id="file_input_help">PDF (Max 5 MB).</p>

                    <center><button class="btn bg-indigo-500 hover:bg-indigo-600 text-white mt-5">
                        <span class="hidden xs:block ml-5 mr-5">Submit</span>
                    </button> </center>

                </div>
            </div>

        </div>

    </div>

    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?><?php /**PATH C:\Users\TSNO - Web Developer\Documents\crm app-web_laravel\resources\views/pages/hr/leaverequest/index.blade.php ENDPATH**/ ?>