<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="px-4 sm:px-6 lg:px-8 py-8 w-full max-w-9xl mx-auto">
        <!-- Page header -->
        <div class="sm:flex sm:justify-between sm:items-center mb-8">
            <!-- Left: Title -->
            <div class="mb-4 sm:mb-0">
                <h1 class="text-2xl md:text-3xl text-slate-800 font-bold">
                    Attendance List ⭐
                </h1>
            </div>
        </div>

        <!-- Table -->
        <label class="flex flex-row">
            <p class="flex flex-row text-lg text-slate-800 mb-3">Filter :</p>
            <select id="leaverequest" class="flex flex-row ml-3 mb-3">
                <option>December</option>
                <option>January</option>
                <option>February</option>
                <option>March</option>
                <option>April</option>
                <option>Mei</option>
                <option>June</option>
                <option>July</option>
                <option>August</option>
                <option>September</option>
                <option>October</option>
                <option>November</option>
            </select>
            <select id="Leaves" class="ml-3 mb-3">
                <option>2022</option>
                <option>2021</option>
                <option>2020</option>
                <option>2019</option>
                <option>2018</option>
                <option>2017</option>
                <option>2016</option>
                <option>2015</option>
                <option>2014</option>
                <option>2013</option>
                <option>2012</option>
                <option>2011</option>
            </select>
        </label>
        <div class="table-responsive">
            <table id="attendancelist" class="table table-striped table-bordered text-xs text-center" style="width:100%">
                <thead>
                    <tr>
                        <th>Date</th>
                        <th>Clock In</th>
                        <th>Clock Out</th>
                        <th>Total Work Hours</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>2022-12-01</td>
                        <td>08:00</td>
                        <td>09:05</td>
                        <td>01:05</td>
                        <td>
                            <button class='text-blue-400 underline'>Request Update</button>
                        </td>
                    </tr>
                    <tr>
                        <td>2022-12-02</td>
                        <td>08:05</td>
                        <td>09:05</td>
                        <td>01:00</td>
                        <td>
                            <button class='text-blue-400 underline'>Request Update</button>
                        </td>
                    </tr>
                    <tr>
                        <td>2022-12-03</td>
                        <td>09:00</td>
                        <td>13:00</td>
                        <td>04:00</td>
                        <td>
                            <button class='text-blue-400 underline'>Request Update</button>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>

    <?php $__env->startSection('js-page'); ?>
    <script>
        $(document).ready(function () {
            $('#approve').DataTable({
                responsive: true,
                processing: true,
                serverSide: false,
                stateServe: true,
                bFilter: false,
                columnDefs: [
                    { className: 'text-center', targets: [0, 1, 2, 3, 4] },
                    { className: 'text-right', targets: [] },
                ], lengthMenu: [[30, 50, 100, -1], [30, 50, 100, 'All']]
            });
        });
    </script>
    <?php $__env->stopSection(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?><?php /**PATH C:\Users\TSNO - Web Developer\Documents\crm app-web_laravel\resources\views/pages/hr/attendancelist/index.blade.php ENDPATH**/ ?>