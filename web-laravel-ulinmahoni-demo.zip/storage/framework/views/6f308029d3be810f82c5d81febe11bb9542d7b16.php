<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="px-4 sm:px-6 lg:px-8 py-8 w-full max-w-9xl mx-auto">
        <!-- Page header -->
        <div class="sm:flex sm:justify-between sm:items-center mb-8">
            <!-- Left: Title -->
            <div class="mb-4 sm:mb-0">
                <h1 class="text-2xl md:text-3xl text-slate-800 font-bold">
                    Project Proposal 🗄️
                </h1>
            </div>
        </div>

        <!-- Table -->
        <div class="flex flex-row text-xs">
            <label class="flex flex-row text-xs">
                <p class="flex flex-row text-slate-800 mb-3 text-sm" for="status">Project Status :</p>
                <select id="status" class="status flex flex-row ml-3 mb-3 text-xs" name="status">
                    <option value="">All</option>
                    <option value="1">Open</option>
                    <option value="0">Pending</option>
                    <option value="2">Lost</option>
                    <option value="3">Won</option>
                </select>
                
                <a class="ml-10 btn bg-indigo-500 hover:bg-indigo-600 text-white text-xs <?php if(Route::is('proyek.form')): ?><?php echo e('!text-indigo-500'); ?><?php endif; ?> mb-3"
                    href="<?php echo e(route('proyek-single.form')); ?>">
                    <svg class="w-4 h-4 fill-current opacity-50 shrink-0" viewBox="0 0 16 16">
                        <path
                            d="M15 7H9V1c0-.6-.4-1-1-1S7 .4 7 1v6H1c-.6 0-1 .4-1 1s.4 1 1 1h6v6c0 .6.4 1 1 1s1-.4 1-1V9h6c.6 0 1-.4 1-1s-.4-1-1-1z" />
                    </svg>
                    <span class="ml-2 text-xs">Create New Proposal</span>
                </a>
            </label>
        </div>
        <div class="table-responsive">
            <table id="proyek" class="table table-striped table-bordered text-xs" style="width:100%">
                <thead>
                    <tr>
                        <th></th>
                        <th class="text-center">Date</th>
                        <th class="text-center">Project</th>
                        <th class="text-center">Customer</th>
                        <th class="text-center">Stage</th>
                        <th class="text-center">Sales Representative</th>
                        <th class="text-center">Project Status</th>
                        <th class="text-center">Action</th>
                    </tr>
                </thead>
            </table>
        </div>
    </div>

    <?php $__env->startSection('js-page'); ?>
    <script>
        $(document).ready(function () {
            $('#proyek').DataTable({
                responsive: true,
                processing: true,
                serverSide: false,
                stateServe: true,
                order: [[1, 'desc']],
                language: {
                    search: "Search Customer Name: "
                },
                ajax: {
                    url: "<?php echo e(route('proyek-single.getdata')); ?>",
                    data:function(d){
                        d.status = $("#status").val()
                        d.salesname = $("#salesname").val()
                    }
                },
                columns: [
                    {
                        data: "label",
                        name: "label"
                    },
                    {
                        data: "created_at",
                        name: "created_at"
                    },
                    {
                        data: "name",
                        name: "name"
                    },
                    {
                        data: "companyname",
                        name: "companyname"
                    },
                    {
                        data: "stage_name",
                        name: "stage_name"
                    },
                    {
                        data: "salesname",
                        name: "salesname"
                    },
                    {
                        data: "status_name",
                        name: "status_name"
                    },
                    {
                        data: "action",
                        name: "action"
                    },
                ],
                columnDefs: [
                    { className: 'text-center', targets: [5] },
                ], lengthMenu: [[30, 50, 100, -1], [30, 50, 100, 'All']]
            });


            $(".status").on('change', function (e) {
                e.preventDefault();
                $('#proyek').DataTable().ajax.reload();
            })
            $(".salesname").on('change', function (e) {
                e.preventDefault();
                $('#proyek').DataTable().ajax.reload();
            })

            // $('#proyek').on("click", ".btn-update", function () {
            //     const companyId = $(this).data("company-id");
            //     const company = $(this).data("company");
            //     const pic = $(this).data("company-pic-id");
            //     const sales = $(this).data("sales");
            //     const project = $(this).data("project");
            //     const description = $(this).data("description");
            //     const notes = $(this).data("notes");
            //     const status = $(this).data("status");
            //     const file = $(this).data("file");

            //     $(".pic").empty();
            //     $(".sales").empty();

            //     $.ajax({
            //         type: "GET",
            //         url: `/tasks/proyek/getupdate/${companyId}`,
            //         success: function (response) {
            //             let picList = '';
            //             for (const value of response.companyPicList) {
            //                 picList += `<option value="${value.id}" ${value.id == pic ? 'selected' : ''}>${value.name} (${value.phone_number_1} / ${value.phone_number_2})</option>`;
            //             }
            //             let salesList = '';
            //             for (const value of response.salesList) {
            //                 salesList += `<option value="${value.id}" ${value.id == sales ? 'selected' : ''}>${value.username}</option>`;
            //             }

            //             $(".company").val(company);
            //             $(".pic").append(picList);
            //             $(".sales").append(salesList);
            //             $(".project-name").val(project);
            //             $(".description").val(description);
            //             $(".notes").val(notes);
            //             $(".file").val(file);
            //         }
            //     });
            // });
        });
    </script>
    <?php $__env->stopSection(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?><?php /**PATH C:\Users\TSNO - Web Developer\Documents\crm app-web_laravel\resources\views/pages/tasks/proyek/proyek-single/index-single.blade.php ENDPATH**/ ?>