<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="px-4 sm:px-6 lg:px-8 py-8 w-full max-w-9xl mx-auto">
        <!-- Page header -->
        <div class="sm:flex sm:justify-between sm:items-center mb-8">
            <!-- Left: Title -->
            <div class="mb-4 sm:mb-0">
                <h1 class="text-2xl md:text-3xl text-slate-800 font-bold">
                    Inventory List 📋
                </h1>
            </div>
        </div>

        
        <div class="flex flex-row mb-3">
            <div class="flex flex-row rounded-full bg-green-700 h-5 w-5"></div>
            <p class="flex flex-row ml-1">Active</p>
            <div class="rounded-full bg-black md:break-after-column h-5 w-5 ml-5"></div>
            <p class="flex flex-row ml-1">Not Active</p>
        </div>

         <!-- label -->
         <div class="flex flex-row text-xs">
            <label class="flex flex-row text-xs">
                <p class="flex flex-row text-slate-800 mb-3 text-sm mt-2" for="status">Project Status :</p>
                <select id="status" class="status flex flex-row ml-3 mb-3 text-xs" name="status">
                    <option value="">All</option>
                    <option value="1">Active</option>
                    <option value="0">Not Active</option>
                </select>
                <p class="flex flex-row text-slate-800 mb-3 text-sm mt-2 ml-3" for="hidden_zero">Show 0 (zero) Stock :</p>
                <select id="hidden_zero" class="hidden_zero flex flex-row ml-3 mb-3 text-xs" name="hidden_zero">
                    <option value="0">Yes</option>
                    <option value="1" selected>No</option>
                </select>
        </div>

        <!-- Table -->
        <div class="table-responsive">
            <table id="invlist" class="table table-striped table-bordered text-xs" style="width:100%">
                <thead>
                    <tr>
                        <th class="text-center">label</th>
                        <th class="text-center">Inventory Code</th>
                        <th class="text-center">Inventory Name</th>
                        <th class="text-center">Unit</th>
                        <th class="text-center">On Hand Stock</th>
                        <th class="text-center">Action</th>
                    </tr>
                </thead>
            </table>
        </div>
    </div>

    <?php $__env->startSection('js-page'); ?>
    <script>
        $(document).ready(function () {
            $('#invlist').DataTable({
                responsive: true,
                processing: true,
                serverSide: false,
                stateServe: true,
                "order": [[ 2, "asc" ]],
                language: {
                    search: "Search Inventory Name: "
                },
                ajax: {
                    url: "<?php echo e(route('invlist.getdata')); ?>",
                    data:function(d){
                        d.status = $("#status").val()
                        d.stock = $("#hidden_zero").val()
                    }
                },
                columns: [
                    {
                        data: "label",
                        name: "label"
                    },
                    {
                        data: "code",
                        name: "code"
                    },
                    {
                        data: "name",
                        name: "name"
                    },
                    {
                        data: "unit",
                        name: "unit"
                    },
                    {
                        data: "global_stock",
                        name: "global_stock"
                    },
                    {
                        data: "action",
                        name: "action"
                    },
                ],
                columnDefs: [
                    { className: 'text-center', targets: [1, 3, 4] },
                    { className: 'flex justify-center', targets: [0, 5] },
                ], lengthMenu: [[30, 50, 100, -1], [30, 50, 100, 'All']]
            });
        });

        $(".status").on('change', function (e) {
                e.preventDefault();
                $('#invlist').DataTable().ajax.reload();
            })

        $(".hidden_zero").on('change', function (e) {
            $('#invlist').DataTable().ajax.reload();
        })

        $('#invlist').on("click", ".btn-modal", function () {
                const id = $(this).data('id');
                const code = $(this).data("code");
                const file1 = $(this).data("file1");
                const file2 = $(this).data("file2");
                const file3 = $(this).data("file3");
                const file1_name = $(this).data("file1_name");
                const file2_name = $(this).data("file2_name");
                const file3_name = $(this).data("file3_name");

                $.ajax({
                    type: "GET",
                    url: `/inventory/invlist/getdetail/${code}`,
                    success: function (response) {

                        $(".modal-content").html(`
                                <div class="px-5">
                                    <div class="grid md:grid-cols-3 gap-3 mt-3">
                                        <div></div>
                                        <div class="${file3 == 1 ? '' : 'hidden'}">
                                            <label class="text-sm font-medium mb-1">Image Not Uploaded Yet</label>
                                        </div>
                                        <div></div>
                                    </div>
                                    <div class="grid md:grid-cols-3 gap-3 mt-3">
                                        <div class="${file1 == 1 ? 'hidden' : ''}">
                                            <label class="text-sm font-medium mb-1">View Image 1 :</label>
                                            <a href="/inventory/invlist/file1/${code}" target="_blank" class="text-sm font-medium ml-5">View Image</a>
                                            <img class="w-full mt-3" src="http://mmp.integrated-os.cloud/${file1_name}" width="259" height="142" alt="Product Image" />
                                        </div>
                                        <div class="${file2 == 1 ? 'hidden' : ''}">
                                            <label class="text-sm font-medium mb-1">View Image 2 :</label>
                                            <a href="/inventory/invlist/file2/${code}" target="_blank" class="text-sm font-medium ml-5">View Image</a>
                                            <img class="w-full mt-3" src="http://mmp.integrated-os.cloud/${file2_name}" width="259" height="142" alt="Product Image" />
                                        </div>
                                        <div class="${file3 == 1 ? 'hidden' : ''}">
                                            <label class="text-sm font-medium mb-1">View Image 3 :</label>
                                            <a href="/inventory/invlist/file3/${code}" target="_blank" class="text-sm font-medium ml-5">View Image</a>
                                            <img class="w-full mt-3" src="http://mmp.integrated-os.cloud/${file3_name}" width="259" height="142" alt="Product Image" />
                                        </div>
                                    </div>
                                </div>
                        `); 
                    },
                });
            });
    </script>
    <?php $__env->stopSection(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?><?php /**PATH /home/iosadmin/web-laravel-mmp/resources/views/pages/inventory/invlist/index.blade.php ENDPATH**/ ?>