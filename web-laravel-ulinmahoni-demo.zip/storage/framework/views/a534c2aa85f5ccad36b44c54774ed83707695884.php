<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['background' => 'bg-white']); ?>
    <div class="px-4 sm:px-6 lg:px-8 py-8 w-full max-w-9xl mx-auto">
        <!-- Page header -->
        <div class="mb-8">
            <h1 class="text-2xl md:text-3xl text-slate-800 font-bold">Progress Detail 📝</h1>
        </div>
        <form action="<?php echo e(route('kan-ban.update', ['kanbanId' => $kanbanData->id])); ?>" method="post" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="px-5 py-4">
                <div class="space-y-3">
                    <div class="flex justify-between flex-col md:flex-row">
                        <label class="block w-full md:w-1/4 text-sm font-medium mb-1" for="name">Kanban Name :</label>
                        <input id="name" name="name" class=" name form-input w-full md:w-3/4 px-2 py-1"
                            value="<?php echo e($kanbanData->ToDo); ?>"/>
                    </div>
                    <div class="flex justify-between flex-col md:flex-row">
                        <label class="block w-full md:w-1/4 text-sm font-medium mb-1" for="type">Type : </label>
                        <input id="type" name="type" class="type form-input w-full md:w-3/4 px-2 py-1 read-only:bg-slate-200" type="text"
                            value="<?php echo e($kanbanData->ToDoType); ?>" readonly disabled />
                    </div>
                    <?php if($kanbanData->ToDoType == "group"): ?>
                        <div class="flex justify-between flex-col md:flex-row">
                            <label class="block w-full md:w-1/4 text-sm font-medium mb-1" for="type">Invite List: </label>
                            <input id="type" name="type" class="type form-input w-full md:w-3/4 px-2 py-1 read-only:bg-slate-200" type="text"
                            value="<?php echo e($kanbanData->invitations); ?>" readonly disabled />
                        </div>
                    <?php endif; ?>
                    <div class="flex justify-between flex-col md:flex-row">
                        <label class="block w-full md:w-1/4 text-sm font-medium mb-1" for="board">Kanban Board : </label>
                        <select id="board" name="board" class="board form-input w-full md:w-3/4 px-2 py-1" type="text">
                            <option name="" id="">Select Here</option>
                            <?php $__currentLoopData = $kanbanBoard; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $board): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($board->id); ?>" <?php echo e($kanbanData->KanBanBoard_ID == $board->id ? ' selected' : ''); ?>><?php echo e($board->BoardName); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="flex justify-between flex-col md:flex-row">
                        <label class="block w-full md:w-1/4 text-sm font-medium mb-1" for="date">Kanban Date : </label>
                        <input id="date" name="date" class="date w-full md:w-3/4 px-2 py-1" type="date"
                            value="<?php echo e($kanbanData->ToDoDate); ?>" />
                    </div>
                    <div class="flex justify-between flex-col md:flex-row">
                        <label class="block w-full md:w-1/4 text-sm font-medium mb-1" for="due">Kanban Due Date : </label>
                        <input id="due" name="due" class="due w-full md:w-3/4 px-2 py-1" type="date"
                            value="<?php echo e($kanbanData->ToDoDue); ?>" />
                    </div>
                    <div class="flex justify-between flex-col md:flex-row">
                        <label class="block w-full md:w-1/4 text-sm font-medium mb-1" for="desc">Description : </label>
                        <textarea id="desc" name="desc" class="desc form-input w-full md:w-3/4 px-2 py-1 read-only:bg-slate-200" type="text" rows="3"
                            value="<?php echo e($kanbanData->ToDoDescription); ?>" readonly/><?php echo e($kanbanData->ToDoDescription); ?></textarea>
                    </div>
                    <div class="flex justify-between flex-col md:flex-row">
                        <label class="block w-full md:w-1/4 text-sm font-medium mb-1" for="file">Upload Image :
                        </label>
                        <input name="photo" class="photo form-input w-full md:w-3/4 px-2 py-1" type="file" accept="image/jpeg" onchange="loadFileMultiple(event, 'output1')" required/>
                    </div>
                    <div class="flex justify-between flex-col md:flex-row ml-72 mt-3">
                        <img id="output1" style="max-width: 300px; max-height: 150px"/>
                    </div>  
                    <div class="flex justify-between flex-col md:flex-row">
                        <label class="block w-full md:w-1/4 text-sm font-medium mb-1" for=""></label>
                        <input id="company" name="file"
                            class="file form-input w-full md:w-3/4 px-2 py-1 read-only:bg-slate-200 mb-3" type="text"
                            readonly disabled value="<?php echo e($kanbanData->ToDoPhoto_name); ?>" />
                    </div>
                    <div class="flex justify-between flex-col md:flex-row">
                        <label class="block w-full md:w-1/4 text-sm font-medium mb-1" for="desc">Kanban List : </label>
                    </div>
                        <?php $__currentLoopData = $dataList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($kanbanData->id == $list->kanban_id): ?>
                                <?php if($list->status == '0'): ?>    
                                        <li class="flex items-center border-t border-slate-200 py-2">
                                            <svg class="w-3 h-3 shrink-0 fill-current text-slate-400 mr-2" viewBox="0 0 12 12">
                                            <path d="M10.28 1.28L3.989 7.575 1.695 5.28A1 1 0 00.28 6.695l3 3a1 1 0 001.414 0l7-7A1 1 0 0010.28 1.28z" />
                                            </svg>
                                            <div class="text-sm" name="list"><?php echo e($list->ToDoList); ?></div>
                                            <input type="text" name="id[]" value="<?php echo e($list->id); ?>" hidden/>
                                            <input type="checkbox" id="check" name="check[<?php echo e($list->id); ?>]" value="1" class="form-input ml-2"/>
                                        </li>
                                    <?php elseif($list->status == '1'): ?>
                                        <li class="flex items-center border-t border-slate-200 py-2">
                                            <svg class="w-3 h-3 shrink-0 fill-current text-emerald-500 mr-2" viewBox="0 0 12 12">
                                                <path d="M10.28 1.28L3.989 7.575 1.695 5.28A1 1 0 00.28 6.695l3 3a1 1 0 001.414 0l7-7A1 1 0 0010.28 1.28z" />
                                            </svg>
                                            <div class="text-sm text-slate-400 line-through"><?php echo e($list->ToDoList); ?></div>
                                            <input type="checkbox" id="uncheck" name="uncheck[<?php echo e($list->id); ?>]" value="0" class="form-input ml-2" selected="selected"/>
                                        </li>
                                <?php endif; ?>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <!-- Modal footer -->
            <div class="px-5 py-4 border-t border-slate-200">
            <?php if($kanbanData->created_by == Auth::user()->id): ?>                                                                            
            <div class="flex flex-wrap justify-end space-x-2">
                <button class="btn-sm text- bg-indigo-500 hover:bg-indigo-600 text-white" type="submit">Update</button>
            </div>
            <?php endif; ?>
            </div>
                </div>
            </div>
        </form>
    </div>

    <?php $__env->startSection('js-page'); ?>
    <script>
    </script>
    <?php $__env->stopSection(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?><?php /**PATH C:\Users\TSNO - Web Developer\Documents\web-laravel-iss\resources\views/pages/kan-ban/updatekanban.blade.php ENDPATH**/ ?>