<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="px-4 sm:px-6 lg:px-8 py-8 w-full max-w-9xl mx-auto">
        <!-- Page header -->
        <div class="sm:flex sm:justify-between sm:items-center mb-8">
            <!-- Left: Title -->
            <div class="mb-4 sm:mb-0">
                <h1 class="text-2xl md:text-3xl text-slate-800 font-bold">
                    Proposal History 📋
                </h1>
            </div>
        </div>

        <!-- Table -->
        <div class="table-responsive">
            <table id="task_history" class="table table-striped table-bordered text-xs" style="width:100%">
                <thead>
                    <tr>
                        <th>Project ID</th>
                        <th>Status</th>
                        <th>Stage</th>
                        <th>Notes</th>
                        <th>Success Rate</th>
                    </tr>
                </thead>
            </table>
        </div>
    </div>

    <?php $__env->startSection('js-page'); ?>
    <script>
        $(document).ready(function () {
            $('#taskhistory').DataTable({
                responsive: true,
                processing: true,
                bfilter: false,
                serverSide: false,
                lengthChange: false,
                stateServe: true,
                ajax: {
                    url: "<?php echo e(route('taskhistoryData')); ?>"
                },
                columns: [
                    {
                        data: "project_id",
                        name: "project_id"
                    },
                    {
                        data: "project_status_id",
                        name: "project_status_id"
                    },
                    {
                        data: "stage_id",
                        name: "stage_id"
                    },
                    {
                        data: "notes",
                        name: "notes"
                    },
                    {
                        data: "success_rate",
                        name: "success_rate"
                    }
                ],
                columnDefs: [
                    { className: 'text-center', targets: [ 4] },
                ]
            });
        });
    </script>
    <?php $__env->stopSection(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?><?php /**PATH C:\Users\TSNO - Web Developer\Documents\crm app-web_laravel\resources\views/pages/tasks/proyek/task-history.blade.php ENDPATH**/ ?>