<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="px-4 sm:px-6 lg:px-8 py-8 w-full max-w-9xl mx-auto">
        <!-- Page header -->
        <div class="sm:flex sm:justify-between sm:items-center mb-8">
            <!-- Left: Title -->
            <div class="mb-4 sm:mb-0">
                <h1 class="text-2xl md:text-3xl text-slate-800 font-bold">
                    Leave Approval 1 📚
                </h1>
            </div>
        </div>

        <div class="flex flex-row mb-3">
            <div class="rounded-full bg-yellow-200 columns-1 h-5 w-5 ml-5"></div>
            <p class="flex flex-row ml-1">Pending</p>
            <div class="rounded-full bg-green-700 columns-1 h-5 w-5 ml-5"></div>
            <p class="flex flex-row ml-1">Approved</p>
            <div class="rounded-full bg-red-500 md:break-after-column h-5 w-5 ml-5"></div>
            <p class="flex flex-row ml-1">Denied</p>
        </div>

        <!-- Table -->
        <div class="table-responsive">
            <table id="approve" class="table table-striped table-bordered text-xs" style="width:100%">
                <thead>
                    <tr>
                        <th></th>
                        <th class="text-center">Form Date</th>
                        <th class="text-center">Leave Request #</th>
                        <th class="text-center">Employee</th>
                        <th class="text-center">Start Leave</th>
                        <th class="text-center">End Leave</th>
                        <th class="text-center" hidden>Leave Days</th>
                        <th class="text-center">Type</th>
                        <th class="text-center">Notes</th>
                        <th class="text-center">Approval 1 Status</th>
                        <th class="text-center">Status</th>
                        <th class="text-center">Action</th>
                    </tr>
                </thead>
            </table>
        </div>
    </div>

    <?php $__env->startSection('js-page'); ?>
    <script>
         $(document).ready(function () {
            $('#approve').DataTable({
                responsive: true,
                processing: true,
                serverSide: false,
                stateServe: true,
                "order": [[ 1, "desc" ]],
                language: {
                    search: "Search : "
                },
                ajax: {
                    url: "<?php echo e(route('leaveapproval.getdata')); ?>"
                },
                columns: [
                    {
                        data: "label",
                        name: "label"
                    },
                    {
                        data: "created_at",
                        name: "created_at"
                    },
                    {
                        data: "id",
                        name: "id"
                    },
                    {
                        data: "employee",
                        name: "employee"
                    },
                    {
                        data: "periode_from",
                        name: "periode_from"
                    },
                    {
                        data: "periode_to",
                        name: "periode_to"
                    },
                    {
                        data: "category",
                        name: "category"
                    },
                    {
                        data: "description",
                        name: "description"
                    },
                    {
                        data: "approval1_status",
                        name: "approval1_status"
                    },
                    {
                        data: "status",
                        name: "status"
                    },
                    {
                        data: "action",
                        name: "action"
                    },
                ],
                columnDefs: [
                    { className: 'text-center', targets: [0, 1,3, 4, 5, 8, 9, 10] },
                    { className: 'text-right', targets: [] },
                ], lengthMenu: [[30, 50, 100, -1], [30, 50, 100, 'All']]
            });

            $('#approve').on("click", ".btn-modal", function () {
                const id = $(this).data('id');
                const date = $(this).data('date');
                const from = $(this).data("from");
                const to = $(this).data("to");
                const employee = $(this).data("employee");
                const desc = $(this).data("desc");
                const status = $(this).data("stat");
                const image = $(this).data("image");
                const approve1_stat = $(this).data("approve1_stat");
                const approve1_name = $(this).data("approve1_name");
                const approve2_stat = $(this).data("approve2_stat");
                const approve2_name = $(this).data("approve2_name");
                const approve1_notes = $(this).data("approve1_notes");
                const approve2_notes = $(this).data("approve2_notes");
                const file_name = $(this).data("file_name");

                $.ajax({
                    type: "GET",
                    url: `/hr/leaveapproval/getdetail/${id}`,
                    success: function (response) {
                        $(".modal-content").html(`
                        <div class="px-5">
                                <div class="text-sm">
                                    <div class="font-medium text-slate-800 mb-3"></div>
                                </div>
                                <div class="grid md:grid-cols-3 gap-3">
                                    <div>
                                        <label class="block text-sm font-medium mb-1"
                                            for="id">Leave Request #</label>
                                        <input id="id" class="id form-input w-full px-2 py-1 bg-slate-100"
                                            type="text" value="${id}" disabled readonly/>
                                    </div>
                                    <div>
                                        <label class="block text-sm font-medium mb-1"
                                            for="date">Form Date</label>
                                        <input id="date" class="date form-input w-full px-2 py-1 bg-slate-100"
                                            type="text" value="${date}" disabled readonly/>
                                    </div>
                                    <div>
                                        <label class="block text-sm font-medium mb-1" for="employee">Employee</label>
                                        <input id="employee" class="employee form-input w-full px-2 py-1 bg-slate-100"
                                            type="text" value="${employee}" disabled
                                            readonly />
                                    </div>
                                    <div>
                                        <label class="block text-sm font-medium mb-1" for="status">Status Leave</label>
                                        <input id="status" class="status form-input w-full px-2 py-1 bg-slate-100"
                                            type="text" value="${status}" disabled readonly />
                                    </div>
                                    <div>
                                        <label class="block text-sm font-medium mb-1" for="approve1_stat">Approval 1 Status</label>
                                        <input id="approve1_stat" class="approve1_stat form-input w-full px-2 py-1 bg-slate-100"
                                            type="text" value="${approve1_stat}" disabled readonly />
                                    </div>
                                    <div>
                                        <label class="block text-sm font-medium mb-1" for="approve2_stat">Approval 2 Status</label>
                                        <input id="approve2_stat" class="approve2_stat form-input w-full px-2 py-1 bg-slate-100"
                                            type="text" value="${approve2_stat}" disabled readonly />
                                    </div>
                                    <div>
                                        <label class="block text-sm font-medium mb-1" for="approve1_name">Approval 1 name</label>
                                        <input id="approve1_name" class="approve1_name form-input w-full px-2 py-1 bg-slate-100"
                                            type="text" value="${approve1_name}" disabled readonly />
                                    </div>
                                    <div>
                                        <label class="block text-sm font-medium mb-1" for="approve2_name">Approval 2 name</label>
                                        <input id="approve2_name" class="approve2_name form-input w-full px-2 py-1 bg-slate-100"
                                            type="text" value="${approve2_name}" disabled readonly />
                                    </div>
                                </div>
                                    <div class="mt-3">
                                        <label class="block text-sm font-medium mb-1 text-left" for="description">Notes</label>
                                        <textarea rows="4" id="description" name="description" class="description form-input w-full px-2 py-1 bg-slate-100"
                                        type="text" disabled readonly>${desc}</textarea>
                                    </div>
                                    <div class="mt-3">
                                        <label class="block text-sm font-medium mb-1 text-left" for="approve1_notes">Approve 1 Notes</label>
                                        <textarea rows="4" id="approve1_notes" class="approve1_notes form-input w-full px-2 py-1 bg-slate-100"
                                        type="text" disabled readonly>${approve1_notes}</textarea>
                                    </div>
                                    <div class="mt-3">
                                        <label class="block text-sm font-medium mb-1 text-left" for="approve2_notes">Approve 2 Notes</label>
                                        <textarea rows="4" id="approve2_notes" class="approve2_notes form-input w-full px-2 py-1 bg-slate-100"
                                        type="text" disabled readonly>${approve2_notes}</textarea>
                                    </div>
                                    <div class="mt-3 mb-5 text-left ${image == 1 ? 'hidden' : ''}">
                                        <label class="text-sm font-medium mb-1">Document Uploaded :</label>
                                        <a href="/hr/leaverequest/leaverequests/document/${id}" target="_blank" class="text-sm font-medium ml-5 text-blue-500 underline">View Document</a>
                                        <input id="file" name="file" class="file read-only:bg-slate-200 px-auto py-1 ml-5" type="text"
                                        readonly disabled value="${file_name}" />
                                    </div>
                            </div>
                        `); 
                    },
                });
            });

            $('#approve').on("click", ".btn-approve", function () {
                const id = $(this).data('id');
                const date = $(this).data('date');
                const from = $(this).data("from");
                const to = $(this).data("to");
                const employee = $(this).data("employee");
                const desc = $(this).data("desc");
                const status = $(this).data("stat");
                const image = $(this).data("image");
                const approve1_stat = $(this).data("approve1_stat");
                const approve1_name = $(this).data("approve1_name");
                const approve2_stat = $(this).data("approve2_stat");
                const approve2_name = $(this).data("approve2_name");
                const approve1_notes = $(this).data("approve1_notes");
                const approve2_notes = $(this).data("approve2_notes");
                const file_name = $(this).data("file_name");

                $.ajax({
                    type: "GET",
                    url: `/hr/leaveapproval/getdetail/${id}`,
                    success: function (response) {
                        const csrf_token = $('meta[name="csrf-token"]').attr('content');
                        $(".modal-content").html(`
                        <div class="px-5">
                                <div class="text-sm">
                                    <div class="font-medium text-slate-800 mb-3"></div>
                                </div>
                                <div class="grid md:grid-cols-3 gap-3">
                                    <div>
                                        <label class="block text-sm font-medium mb-1"
                                            for="id">Leave Request #</label>
                                        <input id="id" class="id form-input w-full px-2 py-1 bg-slate-100"
                                            type="text" value="${id}" disabled readonly/>
                                    </div>
                                    <div>
                                        <label class="block text-sm font-medium mb-1"
                                            for="date">Form Date</label>
                                        <input id="date" class="date form-input w-full px-2 py-1 bg-slate-100"
                                            type="text" value="${date}" disabled readonly/>
                                    </div>
                                    <div>
                                        <label class="block text-sm font-medium mb-1" for="employee">Employee</label>
                                        <input id="employee" class="employee form-input w-full px-2 py-1 bg-slate-100"
                                            type="text" value="${employee}" disabled
                                            readonly />
                                    </div>
                                    <div>
                                        <label class="block text-sm font-medium mb-1" for="status">Status Leave</label>
                                        <input id="status" class="status form-input w-full px-2 py-1 bg-slate-100"
                                            type="text" value="${status}" disabled readonly />
                                    </div>
                                    <div>
                                        <label class="block text-sm font-medium mb-1" for="approve1_stat">Approval 1 Status</label>
                                        <input id="approve1_stat" class="approve1_stat form-input w-full px-2 py-1 bg-slate-100"
                                            type="text" value="${approve1_stat}" disabled readonly />
                                    </div>
                                    <div>
                                        <label class="block text-sm font-medium mb-1" for="approve2_stat">Approval 2 Status</label>
                                        <input id="approve2_stat" class="approve2_stat form-input w-full px-2 py-1 bg-slate-100"
                                            type="text" value="${approve2_stat}" disabled readonly />
                                    </div>
                                    <div>
                                        <label class="block text-sm font-medium mb-1" for="approve1_name">Approval 1 name</label>
                                        <input id="approve1_name" class="approve1_name form-input w-full px-2 py-1 bg-slate-100"
                                            type="text" value="${approve1_name}" disabled readonly />
                                    </div>
                                    <div>
                                        <label class="block text-sm font-medium mb-1" for="approve2_name">Approval 2 name</label>
                                        <input id="approve2_name" class="approve2_name form-input w-full px-2 py-1 bg-slate-100"
                                            type="text" value="${approve2_name}" disabled readonly />
                                    </div>
                                </div>
                                    <div class="mt-3">
                                        <label class="block text-sm font-medium mb-1 text-left" for="description">Notes</label>
                                        <textarea rows="4" id="description" name="description" class="description form-input w-full px-2 py-1 bg-slate-100"
                                        type="text" disabled readonly>${desc}</textarea>
                                    </div>
                                    <div class="mt-3 mb-5 text-left ${image == 1 ? 'hidden' : ''}">
                                        <label class="text-sm font-medium mb-1">Document Uploaded :</label>
                                        <a href="/hr/leaverequest/leaverequests/document/${id}" target="_blank" class="text-sm font-medium ml-5 text-blue-500 underline">View Document</a>
                                        <input id="file" name="file" class="file read-only:bg-slate-200 px-auto py-1 ml-5" type="text"
                                        readonly disabled value="${file_name}" />
                                    </div>
                                    <form method="post" enctype="multipart/form-data" action="/hr/leaveapproval/updateapprove/${id}">
                                        <input type="hidden" name="_token" value="${csrf_token}" />
                                        <div class="mt-3">
                                            <label class="block text-sm font-medium mb-1 text-left" for="approve1_notes">Approve 1 Notes</label>
                                            <textarea rows="4" id="approve1_notes" name="approve1_notes" class="approve1_notes form-input w-full px-2 py-1"
                                            type="text"></textarea>
                                        </div>
                                        <div class="grid md:grid-cols-3 gap-3 mt-3">
                                            <div></div>
                                            <input type="submit" value="Approve" name="status" class="btn-sm bg-emerald-500 hover:bg-emerald-600 text-white" />
                                            <div></div>
                                        </div>
                                    </form>
                            </div>
                        `); 
                    },
                });
            });

            $('#approve').on("click", ".btn-denied", function () {
                const id = $(this).data('id');
                const date = $(this).data('date');
                const from = $(this).data("from");
                const to = $(this).data("to");
                const employee = $(this).data("employee");
                const desc = $(this).data("desc");
                const status = $(this).data("stat");
                const image = $(this).data("image");
                const approve1_stat = $(this).data("approve1_stat");
                const approve1_name = $(this).data("approve1_name");
                const approve2_stat = $(this).data("approve2_stat");
                const approve2_name = $(this).data("approve2_name");
                const approve1_notes = $(this).data("approve1_notes");
                const approve2_notes = $(this).data("approve2_notes");
                const file_name = $(this).data("file_name");

                $.ajax({
                    type: "GET",
                    url: `/hr/leaveapproval/getdetail/${id}`,
                    success: function (response) {
                        const csrf_token = $('meta[name="csrf-token"]').attr('content');
                        $(".modal-content").html(`
                        <div class="px-5">
                                <div class="text-sm">
                                    <div class="font-medium text-slate-800 mb-3"></div>
                                </div>
                                <div class="grid md:grid-cols-3 gap-3">
                                    <div>
                                        <label class="block text-sm font-medium mb-1"
                                            for="id">Leave Request #</label>
                                        <input id="id" class="id form-input w-full px-2 py-1 bg-slate-100"
                                            type="text" value="${id}" disabled readonly/>
                                    </div>
                                    <div>
                                        <label class="block text-sm font-medium mb-1"
                                            for="date">Form Date</label>
                                        <input id="date" class="date form-input w-full px-2 py-1 bg-slate-100"
                                            type="text" value="${date}" disabled readonly/>
                                    </div>
                                    <div>
                                        <label class="block text-sm font-medium mb-1" for="employee">Employee</label>
                                        <input id="employee" class="employee form-input w-full px-2 py-1 bg-slate-100"
                                            type="text" value="${employee}" disabled
                                            readonly />
                                    </div>
                                    <div>
                                        <label class="block text-sm font-medium mb-1" for="status">Status Leave</label>
                                        <input id="status" class="status form-input w-full px-2 py-1 bg-slate-100"
                                            type="text" value="${status}" disabled readonly />
                                    </div>
                                    <div>
                                        <label class="block text-sm font-medium mb-1" for="approve1_stat">Approval 1 Status</label>
                                        <input id="approve1_stat" class="approve1_stat form-input w-full px-2 py-1 bg-slate-100"
                                            type="text" value="${approve1_stat}" disabled readonly />
                                    </div>
                                    <div>
                                        <label class="block text-sm font-medium mb-1" for="approve2_stat">Approval 2 Status</label>
                                        <input id="approve2_stat" class="approve2_stat form-input w-full px-2 py-1 bg-slate-100"
                                            type="text" value="${approve2_stat}" disabled readonly />
                                    </div>
                                    <div>
                                        <label class="block text-sm font-medium mb-1" for="approve1_name">Approval 1 name</label>
                                        <input id="approve1_name" class="approve1_name form-input w-full px-2 py-1 bg-slate-100"
                                            type="text" value="${approve1_name}" disabled readonly />
                                    </div>
                                    <div>
                                        <label class="block text-sm font-medium mb-1" for="approve2_name">Approval 2 name</label>
                                        <input id="approve2_name" class="approve2_name form-input w-full px-2 py-1 bg-slate-100"
                                            type="text" value="${approve2_name}" disabled readonly />
                                    </div>
                                </div>
                                    <div class="mt-3">
                                        <label class="block text-sm font-medium mb-1 text-left" for="description">Notes</label>
                                        <textarea rows="4" id="description" name="description" class="description form-input w-full px-2 py-1 bg-slate-100"
                                        type="text" disabled readonly>${desc}</textarea>
                                    </div>
                                    <div class="mt-3 mb-5 text-left ${image == 1 ? 'hidden' : ''}">
                                        <label class="text-sm font-medium mb-1">Document Uploaded :</label>
                                        <a href="/hr/leaverequest/leaverequests/document/${id}" target="_blank" class="text-sm font-medium ml-5 text-blue-500 underline">View Document</a>
                                        <input id="file" name="file" class="file read-only:bg-slate-200 px-auto py-1 ml-5" type="text"
                                        readonly disabled value="${file_name}" />
                                    </div>
                                    <form method="post" enctype="multipart/form-data" action="/hr/leaveapproval/updatedenied/${id}">
                                        <input type="hidden" name="_token" value="${csrf_token}" />
                                        <div class="mt-3">
                                            <label class="block text-sm font-medium mb-1 text-left" for="approve1_notes">Approve 1 Notes</label>
                                            <textarea rows="4" id="approve1_notes" name="approve1_notes" class="approve1_notes form-input w-full px-2 py-1"
                                            type="text"></textarea>
                                        </div>
                                        <div class="grid md:grid-cols-3 gap-3 mt-3">
                                            <div></div>
                                            <input type="submit" value="Denied" name="status" class="btn-sm bg-red-400 border-slate-200 hover:bg-red-500 text-white" />
                                            <div></div>
                                        </div>
                                    </form>

                            </div>
                        `); 
                    },
                });
            });
        });
    </script>
    <?php $__env->stopSection(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?><?php /**PATH C:\Users\TSNO - Web Developer\Documents\web-laravel-iss\resources\views/pages/hr/leaveapproval/index.blade.php ENDPATH**/ ?>