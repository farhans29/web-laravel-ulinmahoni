<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['background' => 'bg-white']); ?>
    <div class="px-4 sm:px-6 lg:px-8 py-8 w-full max-w-9xl mx-auto">
        <!-- Page header -->
        <div class="mb-8">
            <h1 class="text-2xl md:text-3xl text-slate-800 font-bold">Update Delivery Orders 📦</h1>
        </div>
            <div class="px-5 py-4">
                <div class="space-y-3">
                    <div class="flex justify-between flex-col md:flex-row">
                        <label class="block w-full md:w-1/4 text-sm font-medium mb-1" for="code">Order Code :
                        </label>
                        <input id="id" name="id" class=" id form-select w-full md:w-3/4 px-2 py-1"
                            value="<?php echo e($viewDo->id); ?>" disabled hidden />
                        </label>
                        <input id="code" name="code"
                            class="code form-input w-full md:w-3/4 px-2 py-1 read-only:bg-slate-200" type="text"
                            value="<?php echo e($viewDo->code); ?>" readonly disabled />
                    </div>
                    <div class="flex justify-between flex-col md:flex-row">
                        <label class="block w-full md:w-1/4 text-sm font-medium mb-1" for="company">Delivery Order Number : </label>
                        <input id="number" name="number"
                            class="number form-input w-full md:w-3/4 px-2 py-1 read-only:bg-slate-200" type="text"
                            value="<?php echo e($viewDo->do_number); ?>" readonly disabled />
                    </div>
                    <div class="flex justify-between flex-col md:flex-row">
                        <label class="block w-full md:w-1/4 text-sm font-medium mb-1" for="status">Status : </label>
                        <input id="status" name="status"
                            class="status form-input w-full md:w-3/4 px-2 py-1 read-only:bg-slate-200" type="text"
                            value="<?php echo e($viewDo->name_status); ?>" readonly disabled />
                    </div>
                    <div class="flex justify-between flex-col md:flex-row">
                        <label class="block w-full md:w-1/4 text-sm font-medium mb-1" for="date">Delivery Date : </label>
                        <input id="date" name="date"
                            class="date form-input w-full md:w-3/4 px-2 py-1 read-only:bg-slate-200" type="text"
                            value="<?php echo e($viewDo->delivery_date); ?>" readonly disabled />
                    </div>
                    <div class="flex justify-between flex-col md:flex-row">
                        <label class="block w-full md:w-1/4 text-sm font-medium mb-1" for="by">Delivery By : </label>
                        <input id="by" name="by"
                            class="by form-input w-full md:w-3/4 px-2 py-1 read-only:bg-slate-200" type="text"
                            value="<?php echo e($viewDo->delivery_by); ?>" readonly disabled />
                    </div>
                    <div class="flex justify-between flex-col md:flex-row">
                        <label class="block w-full md:w-1/4 text-sm font-medium mb-1" for="company">Delivery Address : </label>
                        <textarea id="notes" name="notes" class="notes form-input w-full md:w-3/4 px-2 py-1 read-only:bg-slate-200"
                            rows="3" readonly disabled><?php echo e($viewDo->delivery_address); ?> </textarea>
                    </div>
                    <div class="table-responsive mt-4">
                        <label class="block text-sm font-medium mb-1" for="address">Delivery Product Items :</label>
                        <table class="table table-striped table-bordered detail-delivery-orders"
                            style="width:100%">
                            <thead>
                                <tr>
                                    <th class="text-sm text-center">Product Code</th>
                                    <th class="text-sm text-center">Product Name</th>
                                    <th class="text-sm text-center">Batch No</th>
                                    <th class="text-sm text-center">Qty</th>
                                    <th class="text-sm text-center">Status</th>
                                </tr>
                            </thead>
                            <tbody class="detail-delivery-orders" id="detail-delivery-orders">
                                
                            </tbody>
                        </table>
                    </div>
                    <form method="post" class="form_do_update" enctype="multipart/form-data" action="<?php echo e(route('do-update.status', ['code' => $viewDo->code])); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="grid md:grid-cols-3 gap-3 mt-3">
                            <div>
                                <label class="block text-sm font-medium mb-1" for="file">AWB DO Upload:</label>
                                <input name="photo1" class="form-input w-full md:w-3/4 px-2 py-1" type="file" accept="image/jpg" onchange="loadFileMultiple(event, 'output1-${code}')" required />
                                <img id="output1-${code}" style="max-width: 300px; max-height: 150px"/>
                            </div>
                            <div></div>
                            <div>
                                <label class="block text-sm font-medium mb-1" for="file">Signed DO Upload:</label>
                                <input name="photo2" class="form-input w-full md:w-3/4 px-2 py-1" type="file" accept="image/jpg" onchange="loadFileMultiple(event, 'output2-${code}')" required />
                                <img id="output2-${code}" style="max-width: 300px; max-height: 150px"/>
                            </div>
                        </div>
                        <div class="grid md:grid-cols-3 gap-3 mt-3">
                                <input type="submit" value="Delivery Confirmed" name="status" class="btn-sm bg-emerald-500 hover:bg-emerald-600 text-white" />
                                <input type="submit" value="Partially Delivered" name="status" class="btn-sm bg-indigo-500 hover:bg-indigo-600 text-white" />
                                <input type="submit" value="Lost in Delivery" name="status" class="btn-sm bg-red-400 border-slate-200 hover:bg-red-500 text-white" />
                        </div>
                    </form>
                </div>
            </div>
    </div>

    <?php $__env->startSection('js-page'); ?>
    <script>
        const dataProducts = JSON.parse('<?= json_encode($dataDeliveryOrders) ?>')
        let tableRow = '';
        let productIdx = 0;
        
        for (const value of dataProducts) {
            console.info(value)
            tableRow += "<tr id=\"row-" + productIdx + "\">\n" +
                "   <td class=\"text-center\">" + value.product_code + "<input type=\"hidden\" name = \"rows[" + productIdx + "][product_code]\" value =" + value.product_code + "></td>\n" +
                "   <td class=\"text-center\">" + value.product_name + "<input type=\"hidden\" name = \"rows[" + productIdx + "][product_name]\" value =" + value.product_name + "></td>\n" +
                "   <td class=\"text-center\">" + value.batch_no + "<input type=\"hidden\" name = \"rows[" + productIdx + "][batch_no]\" value =" + value.batch_no + "></td>\n" +
                "   <td class=\"text-center\">" + value.qty + "<input type=\"hidden\" name = \"rows[" + productIdx + "][qty]\" value =" + value.qty + "></td>\n" +
                "   <td class=\"text-center\">" + value.status_order + "<input type=\"hidden\" name = \"rows[" + productIdx + "][status_order]\" value =" + value.status_order + ">" + "<input type=\"hidden\" name = \"rows[" + productIdx + "][product_id]\" value =" + value.product_id + "></td>\n"
            "</tr>";
            productIdx++;

        }
        $("#detail-delivery-orders").append(tableRow);
    </script>
    <?php $__env->stopSection(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?><?php /**PATH C:\Users\TSNO - Web Developer\Documents\web-laravel-iss\resources\views/pages/logistic/doupdate/doupdatepage.blade.php ENDPATH**/ ?>