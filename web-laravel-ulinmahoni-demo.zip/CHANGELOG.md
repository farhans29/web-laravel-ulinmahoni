# CHANGELOG.md

## [4.5.0] - 2022-09-14

Fix Livewire error with manifest.json 

## [4.4.0] - 2022-09-09

Fix Livewire error with manifest.json 

## [4.3.0] - 2022-07-13

First release